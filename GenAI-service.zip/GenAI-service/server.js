const fetch = require("node-fetch");
const { Buffer } = require("buffer");

const apiKey = "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";
const url = "https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-dev";

// Function to generate image
exports.generateImage = async (req, res) => {
  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).send({ error: "The 'prompt' field is required." });
  }

  try {
    console.log(`Generating image for prompt: "${prompt}"`);

    // Step 1: Call external API to generate the image
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          guidance_scale: 7.5,
          num_inference_steps: 50,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`);
    }

    // Step 2: Convert response to buffer
    const buffer = Buffer.from(await response.arrayBuffer());

    // Step 3: Save the buffer as an image
    fs.writeFileSync("generated_image.png", buffer);
    console.log("Image generated and saved as 'generated_image.png'");
    } catch (error) {
    console.error("Error:", error.message);
    }
}
   
generateImage();
   