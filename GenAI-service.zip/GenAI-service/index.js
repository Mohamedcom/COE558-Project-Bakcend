const fetch = require("node-fetch");
const { Storage } = require("@google-cloud/storage");
const { Buffer } = require("buffer");

// Cloud Storage Configuration
const storage = new Storage({
  keyFilename: "./kfupm-241-coe558-alsaleh-fd46278258d3.json",
});
const bucketName = "object-binary-storage"; // Replace with your Cloud Storage bucket name
const folderPath = "imagesPrompts/"; // Folder to store images

const apiKey = "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";
const huggingFaceURL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-3.5-large";
const crudServiceURL = "https://crud-firestore-service-809589673646.us-central1.run.app/api/prompts";

exports.GenAI = async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === "OPTIONS") {
    // CORS preflight request
    return res.status(204).send();
  }

  if (req.method !== "POST") {
    return res.status(405).send({ error: "Only POST requests are allowed." });
  }

  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).send({ error: "The 'prompt' field is required in the request body." });
  }

  const payload = {
    inputs: prompt,
    parameters: {
      "guidance_scale": 10.0,
      "num_inference_steps": 50,
      "height": 768,
      "width": 768,
      "seed": 42
    },
  };

  try {
    console.log(`Generating image for prompt: "${prompt}"`);

    // Step 1: Call the Hugging Face API
    const response = await fetch(huggingFaceURL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorDetails = await response.json();
      console.error("Error from Hugging Face API:", errorDetails);
      return res.status(response.status).send({
        error: "Failed to generate the image.",
        details: errorDetails,
      });
    }

    // Step 2: Convert response to buffer
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    console.log("Image successfully generated.");

    // Step 3: Upload the image to Cloud Storage
    const fileName = `${folderPath}image-${Date.now()}.png`;
    const file = storage.bucket(bucketName).file(fileName);

    await file.save(buffer, {
      metadata: { contentType: "image/png" },
    });

    console.log("Image uploaded to Cloud Storage.");

    // Step 4: Generate Signed URL
    const [signedUrl] = await file.getSignedUrl({
      action: "read",
      expires: Date.now() + 60 * 60 * 1000, // URL valid for 1 hour
    });

    console.log(`Generated Signed URL: ${signedUrl}`);

    // Step 5: Send POST request to CRUD service
    const crudResponse = await fetch(crudServiceURL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: prompt,
        imageURL: signedUrl,
      }),
    });

    if (!crudResponse.ok) {
      const crudErrorDetails = await crudResponse.json();
      console.error("Error from CRUD Firestore Service:", crudErrorDetails);
      return res.status(crudResponse.status).send({
        error: "Failed to save prompt and image URL to CRUD Firestore Service.",
        details: crudErrorDetails,
      });
    }

    console.log("Prompt and image URL successfully sent to CRUD service.");

    // Step 6: Return the response
    res.status(201).send({
      prompt: prompt,
      imageURL: signedUrl,
    });
  } catch (error) {
    console.error("Error during processing:", error.message);
    res.status(500).send({
      error: "Internal server error while processing the request.",
      details: error.message,
    });
  }
};
