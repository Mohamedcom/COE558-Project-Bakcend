/**
 * @prettier
 */
const durationGenerator = () => "P3D" // expresses a duration of 3 days

export default durationGenerator
