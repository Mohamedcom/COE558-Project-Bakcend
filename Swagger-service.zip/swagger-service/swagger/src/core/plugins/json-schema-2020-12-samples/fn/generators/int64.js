/**
 * @prettier
 */
const int64Generator = () => 2 ** 53 - 1

export default int64Generator
