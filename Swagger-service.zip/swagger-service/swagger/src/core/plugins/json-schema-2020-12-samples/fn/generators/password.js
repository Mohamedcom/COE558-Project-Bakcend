/**
 * @prettier
 */
const passwordGenerator = () => "********"

export default passwordGenerator
