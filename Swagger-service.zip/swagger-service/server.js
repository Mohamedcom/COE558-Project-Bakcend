const express = require("express");
const path = require("path");

const app = express();

// Serve Swagger UI files
app.use("/", express.static(path.join(__dirname, "swagger-ui")));

// Serve OpenAPI YAML
app.get("/swagger.yaml", (req, res) => {
  res.sendFile(path.join(__dirname, "swagger.yaml"));
});

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(`Swagger UI available at http://localhost:${PORT}`);
});
