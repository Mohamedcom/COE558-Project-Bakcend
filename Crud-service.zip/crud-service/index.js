const express = require("express");
const bodyParser = require("body-parser");
const { Firestore } = require("@google-cloud/firestore");
const { Storage } = require("@google-cloud/storage");
const fetch = require("node-fetch");

// Initialize Firestore with service account key
const firestore = new Firestore({
  projectId: "kfupm-241-coe558-alsaleh", // Replace with your Project ID
  keyFilename: "./kfupm-241-coe558-alsaleh-553e093652c6.json", // Path to service account key
});

// Initialize Google Cloud Storage
const storage = new Storage({
  projectId: "kfupm-241-coe558-alsaleh",
  keyFilename: "./kfupm-241-coe558-alsaleh-553e093652c6.json",
});

const bucketName = "object-binary-storage"; // Your Cloud Storage bucket name
const app = express();
app.use(bodyParser.json());

// **CORS Middleware**
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*"); // Allow all origins
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS"); // Allow specific methods
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization"); // Allow specific headers

  if (req.method === "OPTIONS") {
    // Handle preflight requests
    res.status(204).send("");
  } else {
    next();
  }
});

const PORT = process.env.PORT || 8080;

// Helper function to delete the image from Cloud Storage
async function deleteImageFromCloudStorage(imageURL) {
  try {
    const regex = /image-\d+\.png/; // Matches "image-" followed by digits and ".png"
    const match = imageURL.match(regex);

    if (!match) {
      console.warn("No valid image linked to the prompt. Skipping Cloud Storage deletion.");
      return false; // Skip deletion
    }

    const imageName = match[0];
    const filePath = `imagesPrompts/${imageName}`;

    const bucket = storage.bucket(bucketName);
    await bucket.file(filePath).delete();

    console.log(`Image deleted successfully from Cloud Storage: ${filePath}`);
    return true;
  } catch (error) {
    console.error("Error deleting image from Cloud Storage:", error.message);
    throw error;
  }
}

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// Test Route
app.get("/", async (req, res) => {
  try {
    res.status(200).send("Hello COE 558 - CRUD Service for Prompts");
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Create a new prompt
app.post("/api/prompts", async (req, res) => {
  try {
    const data = req.body; // Expect { prompt: "example", imageURL: "url" }
    if (!data.prompt || !data.imageURL) {
      return res.status(400).send({ error: "Fields 'prompt' and 'imageURL' are required." });
    }

    // Save document to Firestore
    const docRef = await firestore.collection("prompts").add({
      prompt: data.prompt,
      imageURL: data.imageURL,
      createdAt: new Date(),
    });

    res.status(201).send({
      message: "Prompt created successfully",
      id: docRef.id,
    });
  } catch (error) {
    res.status(400).send({ error: `Error creating prompt: ${error.message}` });
  }
});

// Read all prompts
app.get("/api/prompts", async (req, res) => {
  try {
    const snapshot = await firestore.collection("prompts").get();

    if (snapshot.empty) {
      return res.status(404).send({ message: "No prompts found." });
    }

    const prompts = [];
    snapshot.forEach((doc) => {
      prompts.push({ id: doc.id, ...doc.data() });
    });

    res.status(200).send(prompts);
  } catch (error) {
    res.status(500).send({ error: `Error retrieving prompts: ${error.message}` });
  }
});

// Update a prompt by ID (only "prompt" field)
app.put("/api/prompts/:id", async (req, res) => {
  try {
    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).send({ error: "The 'prompt' field is required." });
    }

    // Step 1: Get the existing document
    const docRef = firestore.collection("prompts").doc(req.params.id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).send({ error: "No such prompt to update!" });
    }

    // Step 2: Send the updated prompt to the GenAI Service
    const genAIResponse = await fetch("https://us-central1-kfupm-241-coe558-alsaleh.cloudfunctions.net/GenAI-1", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt }),
    });

    if (!genAIResponse.ok) {
      const errorDetails = await genAIResponse.text();
      console.error("Error from GenAI Service:", errorDetails);
      return res.status(500).send({ error: "Failed to generate image from GenAI service." });
    }

    const genAIResult = await genAIResponse.json();
    const newImageURL = genAIResult.imageURL;

    console.log(`New image generated: ${newImageURL}`);

    // Step 3: Update Firestore with the new prompt and imageURL
    await docRef.update({
      prompt: prompt,
      imageURL: newImageURL,
      updatedAt: new Date(),
    });

    res.status(200).send({
      message: "Prompt updated successfully and new image generated.",
      id: req.params.id,
      prompt: prompt,
      imageURL: newImageURL,
    });
  } catch (error) {
    console.error("Error updating prompt:", error.message);
    res.status(400).send({ error: `Error updating prompt: ${error.message}` });
  }
});

// Delete a prompt by ID
app.delete("/api/prompts/:id", async (req, res) => {
  try {
    const docRef = firestore.collection("prompts").doc(req.params.id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).send({ message: "No such prompt to delete!" });
    }

    const { imageURL } = doc.data();

    let imageDeleted = false;
    if (imageURL) {
      try {
        imageDeleted = await deleteImageFromCloudStorage(imageURL);
      } catch (error) {
        console.warn("Skipping Cloud Storage deletion due to error:", error.message);
      }
    }

    await docRef.delete();

    res.status(200).send({
      message: `Prompt deleted successfully. ${
        imageDeleted ? "Image was also deleted from Cloud Storage." : "No valid image linked or deletion skipped."
      }`,
    });
  } catch (error) {
    res.status(400).send({ error: `Error deleting prompt: ${error.message}` });
  }
});
